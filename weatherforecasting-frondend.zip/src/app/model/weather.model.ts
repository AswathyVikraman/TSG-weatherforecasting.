export interface Weather {
  ForecastId: number;
  TemperatureC: string;
  Pressure: string ;
  Humidity: string ;
  CategoryId:number ;
  LocationId:number ;
  Datetime: string;
  ModifiedDate: string ;
  UpdatedBy:number ;
}
