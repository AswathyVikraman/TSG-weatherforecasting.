import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class WeatherAppService {

  private userPayload: any;

  constructor(private http:HttpClient,private router:Router) { }

  getWeatherbycity(city:string):Observable<any>{
    return this.http.get<any>(`https://localhost:7049/api/Weather/get_info/city?city=${city}`)
    // .pipe(map((res:any)=>{
    //   return res;
    // }))
  }
  getRoleFromToken() {
    if (this.userPayload) {
      
      return this.userPayload.role;
    }
  }
}
