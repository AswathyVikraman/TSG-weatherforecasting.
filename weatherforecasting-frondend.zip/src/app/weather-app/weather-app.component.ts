import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { WeatherModel } from '@app/about/about.model';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs';
import { WeatherAppService } from './weather-app.service';

@Component({
  selector: 'app-weather-app',
  templateUrl: './weather-app.component.html',
  styleUrls: ['./weather-app.component.scss']
})
export class WeatherAppComponent implements OnInit {


  searchForm: FormGroup = new FormGroup({
    search: new FormControl('')
  })


  public role!: string;

  public weatherList: Array<any> = [];


  constructor(private auth: WeatherAppService) {

    this.searchForm.get('search')?.valueChanges.
      pipe(
        debounceTime(1000),
        distinctUntilChanged(),
        switchMap((res) =>
          this.auth.getWeatherbycity(res)
        )
      )
      .subscribe(
        (res) => {
          this.weatherList = res.weathermodelobj;
          console.log(res)
        }
      )
  }

  // city? means default value is undefined
  cityName: string = 'trivandrum';
  weatherData?: WeatherModel;
  ngOnInit(): void {
    this.getWeatherData(this.cityName);
    this.cityName = '';

  }
  onSubmit() {
    this.getWeatherData(this.cityName);
    this.cityName = '';
  }
  private getWeatherData(cityName: string) {
    this.auth.getWeatherbycity(cityName)
      .subscribe({
        next: (response) => {
          this.weatherData = response;
          console.log(response);
        }
      })
  }



}
