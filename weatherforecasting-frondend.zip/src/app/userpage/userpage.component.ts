import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService, CredentialsService } from '@app/auth';
import { WeatherService } from '@app/home/weather.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-userpage',
  templateUrl: './userpage.component.html',
  styleUrls: ['./userpage.component.scss']
})
export class UserpageComponent implements OnInit {
  menuHidden = true;
  public username: string = '';
  public role!: string;
  searchText!: any;
  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    private credentialsService: CredentialsService,
    private toaster: ToastrService,

    private formbuilder: FormBuilder,
  ) { }


  ngOnInit(): void {
    
  }
  toggleMenu() {
    this.menuHidden = !this.menuHidden;
  }

  logout() {
    this.authenticationService.logout().subscribe(() => {
      this.toaster.warning('logout successfully');
      this.router.navigate(['/login'], { replaceUrl: true });
    });
  }

 
}
