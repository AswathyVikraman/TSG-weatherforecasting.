import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { map, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class WeatherService {
  // private userPayload: any;
  constructor(private http: HttpClient, private router: Router) {
    // this.userPayload = this.decodeToken()
  }

  postWeather(data: any) {
    return this.http.post<any>(`Forecast`, data).pipe(
      map((res: any) => {
        return res;
      })
    );
  }
  getWeather(){
    return this.http.get<any>(`Forecast/getWeather`);
  }

  getCategory(): Observable<any> {
    return this.http.get<any>('/category');
  }
  // getWeatherbycity(city:string){
  //   return this.http.get<any>(`https://localhost:7049/api/Weather/get_info/city?city=${city}`)
  //   .pipe(map((res:any)=>{
  //     return res;
  //   }))
  // }
  getWeatherbycity(city: string): Observable<any> {
    return this.http.get<any>(`https://localhost:7049/api/Weather/get_info/city?city=${city}`);
    // .pipe(map((res:any)=>{
    //   return res;
    // }))
  }
  updateWeather(data: any) {
    return this.http.put<any>(`Forecast`, data);
  }
  deleteWeather(id: number) {
    return this.http.delete<any>(`Forecast/` + id)
  }
  storeToken(tokenValue: string) {
    localStorage.setItem('token', tokenValue);
  }
  getToken() {
    return localStorage.getItem('token');
  }
}
