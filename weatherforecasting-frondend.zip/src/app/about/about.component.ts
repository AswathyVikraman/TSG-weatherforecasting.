import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { WeatherService } from '@app/home/weather.service';
import { Weather } from '@app/model/weather.model';
import { environment } from '@env/environment';
import { WeatherModel } from './about.model';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss'],
})
export class AboutComponent implements OnInit {
  version: string | null = environment.version;

  public username: string = '';
  public role!: string;
  // currentUserEmail = this.credentialService.credentials?.email;
  // currentUserRole = this.credentialService.credentials?.role;
  // users: any;
  // message: any;
  // addForm!: FormGroup;

  searchText!: any;
  heroes = this.getAllWeather();

  listItems = [];

  formvalue!: FormGroup;

  weathermodelobj: WeatherModel = new WeatherModel();

  weatherData!: any;
  showAdd!: boolean;
  showUpdate!: boolean;
  weather: Weather[] = [];

  constructor(
    private formbuilder: FormBuilder,
    private api: WeatherService,
  ) {}

  ngOnInit(): void {
    this.formvalue = this.formbuilder.group({

      // forecastId: [''],
      temperatureC: [''],
      pressure: [''],
      humidity: [''],
      categoryId: [''],
      locationId: [''],
      datetime: [''],
      modifiedDate: [''],
      updatedBy: [''],


      role: [''],
    });

    //   this.userstore.getUserNameFromStore()
    //   .subscribe(val => {
    //     let usernameFromToken = this.api.getUsernameFromToken();
    //     this.username = val || usernameFromToken
    //   })
    // // to select role to show or hide side navebar
    // this.userstore.getRoleFromStore()
    //   .subscribe(val => {
    //     let roleFromToken = this.api.getRoleFromToken();
    //     this.role = val || roleFromToken;
    //   })

    this.getAllWeather();
  }
  clickAddWeather() {
    this.formvalue.reset();
    this.showAdd = true;
    this.showUpdate = false;
  }

  postWeatherDetails() {
    this.weathermodelobj.ForecastId=this.formvalue.value.forecastId;
    this.weathermodelobj.TemperatureC = this.formvalue.value.temperatureC;
    this.weathermodelobj.Pressure = this.formvalue.value.pressure;
    this.weathermodelobj.Humidity = this.formvalue.value.humidity;
    this.weathermodelobj.CategoryId = this.formvalue.value.categoryId;
    this.weathermodelobj.LocationId = this.formvalue.value.locationId;
    this.weathermodelobj.Datetime = this.formvalue.value.datetime;
    this.weathermodelobj.ModifiedDate = this.formvalue.value.modifiedDate;
    this.weathermodelobj.UpdatedBy = this.formvalue.value.updatedBy;

    // this.weathermodelobj.role = this.formvalue.value.role;
    this.api.postWeather(this.weathermodelobj)
    .subscribe(res => {
      console.log(res);
      alert("Details added successfully!");
      let ref = document.getElementById('cancel');
      ref?.click();
      this.formvalue.reset();
      this.getAllWeather();
    },
      error => {
        alert("something went wrong!");
      })
    
  }
  getAllWeather() {
    this.api.getWeather()
      .subscribe(res => {
        console.log(res)
        this.weatherData = res;
      })
  }

  deleteWeather(row: any) {
    if (confirm('Are you sure??')) {
      this.api.deleteWeather(row.id).subscribe((res) => {
        alert('details deleted!!!!!!');
        this.getAllWeather();
      });
    }
  }
  onEdit(row: any) {
    this.showAdd = false;
    this.showUpdate = true;
    this.weathermodelobj.ForecastId = row.ForecastId;
    this.formvalue.controls['temperature'].setValue(row.TemperatureC);
    this.formvalue.controls['pressure'].setValue(row.Pressure);
    this.formvalue.controls['humidity'].setValue(row.Humidity);
    this.formvalue.controls['categoryId'].setValue(row.CategoryId);
    this.formvalue.controls['locationId'].setValue(row.LocationId);
    this.formvalue.controls['modifieddate'].setValue(row.ModifiedDate);
    this.formvalue.controls['updatedby'].setValue(row.UpdatedBy);
  }
  updateWeatherDetails() {
    this.weathermodelobj.TemperatureC = this.formvalue.value.temperatureC;
    this.weathermodelobj.Pressure = this.formvalue.value.pressure;
    this.weathermodelobj.Humidity = this.formvalue.value.humidity;
    this.weathermodelobj.CategoryId = this.formvalue.value.categoryId;
    this.weathermodelobj.LocationId = this.formvalue.value.locationId;
    this.weathermodelobj.Datetime = this.formvalue.value.datetime;
    this.weathermodelobj.ModifiedDate = this.formvalue.value.modifiedDate;
    this.weathermodelobj.UpdatedBy = this.formvalue.value.updatedBy;
    this.api.updateWeather(this.weathermodelobj).subscribe(
      (res) => {
        alert('updated details!!!!!!!!!!!');
        let ref = document.getElementById('cancel');
        ref?.click();
        this.formvalue.reset();
        this.getAllWeather();
      },
      (error) => {
        alert("somethin went wrong!");
      }
    );
  }
  // logout() {
  //   this.api.signOut();
  // }
}
