export class WeatherModel {
  ForecastId: number = 0;
  TemperatureC: string = '';
  Pressure: string = '';
  Humidity: string = '';
  CategoryId:number = 0;
  LocationId:number = 0;
  Datetime: string = '';
  ModifiedDate: string = '';
  UpdatedBy:number = 0;
  // role:string='';
}
