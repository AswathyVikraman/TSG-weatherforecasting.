import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService, CredentialsService } from '@app/auth';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-aboutweather-user',
  templateUrl: './aboutweather-user.component.html',
  styleUrls: ['./aboutweather-user.component.scss']
})
export class AboutweatherUserComponent implements OnInit {
  menuHidden = true;
  public username: string = '';
  public role!: string;
  searchText!: any;
  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    private credentialsService: CredentialsService,
    private toaster: ToastrService,

    private formbuilder: FormBuilder,
  ) { }


  ngOnInit(): void {
    
  }
  toggleMenu() {
    this.menuHidden = !this.menuHidden;
  }

  logout() {
    this.authenticationService.logout().subscribe(() => {
      this.toaster.warning('logout successfully');
      this.router.navigate(['/login'], { replaceUrl: true });
    });
  }

}
