import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutweatherUserComponent } from './aboutweather-user.component';

describe('AboutweatherUserComponent', () => {
  let component: AboutweatherUserComponent;
  let fixture: ComponentFixture<AboutweatherUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AboutweatherUserComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AboutweatherUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
