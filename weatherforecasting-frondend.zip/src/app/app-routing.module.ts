import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { marker } from '@biesbjerg/ngx-translate-extract-marker';
import { AboutweatherUserComponent } from './aboutweather-user/aboutweather-user.component';
import { HomeUserComponent } from './home-user/home-user.component';
import { UserpageComponent } from './userpage/userpage.component';
import { WeatherAppComponent } from './weather-app/weather-app.component';

const routes: Routes = [
  // Fallback when no prior route is matched
  { path: 'login', redirectTo: '/home-user', pathMatch: 'full' },
  { path: 'home-user', component: HomeUserComponent, data: { title: marker('home-user') } },
  { path: 'aboutweather-user', component: AboutweatherUserComponent, data: { title: marker('aboutweather-user') } },
  { path: 'weather-app', component: WeatherAppComponent, data: { title: marker('weather-app') } },
  { path: 'userpage', component: UserpageComponent, data: { title: marker('userpage') } },
];

  


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [],
})
export class AppRoutingModule {}
