import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable, of } from 'rxjs';

import { Credentials, CredentialsService } from './credentials.service';

export interface LoginContext {
  name: string;
  password: string;
}
export interface RegisterContext {
  username: string;
  email: string;
  password: string;
  roleId: 1;
}

/**
 * Provides a base for authentication workflow.
 * The login/logout methods should be replaced with proper implementation.
 */
@Injectable({
  providedIn: 'root',
})
export class AuthenticationService {
  constructor(private credentialsService: CredentialsService, private http: HttpClient) {}

  /**
   * Authenticates the user.
   * @param context The login parameters.
   * @return The user credentials.
   */
  login(context: LoginContext): Observable<any> {
    console.log(context.name, 'inside service');
    this.http.post('/login', context, { observe: 'response' }).pipe(
      map((res: HttpResponse<any>) => {
        console.log('', res);
        return res.body;
      })
    );
    //console.log("api",x)
    // Replace by proper authentication call
    return this.http.post('Auth/login', context, { observe: 'response' }).pipe(
      map((res: HttpResponse<any>) => {
        return res.body;
      })
    );
  }

  // register(requestObj: RegisterContext): Observable<any> {
  //   return this.http.post(`/register`, requestObj, { observe: 'response' }).pipe(
  //     map((res: HttpResponse<any>) => {
  //       return res.body;
  //     })
  //   );
  // }
  register(context: RegisterContext) {
    console.log(context);
    return this.http.post<any>(`https://localhost:7055/api/Auth/register`, context);
  }
  logout(): Observable<boolean> {
    // Customize credentials invalidation here
    this.credentialsService.clearCredentials();
    return of(true);
  }
}
