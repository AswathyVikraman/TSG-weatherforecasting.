import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutweatherComponent } from './aboutweather.component';

describe('AboutweatherComponent', () => {
  let component: AboutweatherComponent;
  let fixture: ComponentFixture<AboutweatherComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AboutweatherComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AboutweatherComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
