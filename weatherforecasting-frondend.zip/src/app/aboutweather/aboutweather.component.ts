import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutweather',
  templateUrl: './aboutweather.component.html',
  styleUrls: ['./aboutweather.component.scss'],
})
export class AboutweatherComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
